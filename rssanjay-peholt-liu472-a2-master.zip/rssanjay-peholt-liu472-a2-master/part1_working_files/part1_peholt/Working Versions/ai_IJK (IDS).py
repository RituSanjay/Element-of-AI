#!/usr/local/bin/python3

"""
This is where you should write your AI code!

Authors: Chang Liu/Liu472,

Based on skeleton code by Abhilash Kuhikar, October 2019
"""

from logic_IJK import Game_IJK
import random

# Suggests next move to be played by the current player given the current game
#
# inputs:
#     game : Current state of the game 
#
# This function should analyze the current state of the game and determine the 
# best move for the current player. It should then call "yield" on that move.

def next_move(game: Game_IJK)-> None:

    '''board: list of list of strings -> current state of the game
       current_player: int -> player who will make the next move either ('+') or -'-')
       deterministic: bool -> either True or False, indicating whether the game is deterministic or not
    '''

    board = game.getGame()
    player = game.getCurrentPlayer()
    deterministic = game.getDeterministic()

    # You'll want to put in your fancy AI code here. For right now this just 
    # returns a random move.

    # Reminder on sorting in Python:
    # https://stackoverflow.com/questions/409370/sorting-and-grouping-nested-lists-in-python
    level = 0
    if player == "-":
        moves = [['U', best_move(game.makeMove('U'), level)],
                 ['D', best_move(game.makeMove('D'), level)],
                 ['L', best_move(game.makeMove('L'), level)],
                 ['R', best_move(game.makeMove('R'), level)]]
        print(moves)
        moves.sort(key=lambda x: x[1])
        move = moves[0]

        yield move[0]
    elif player == "+":
        moves = [['U', best_move(game.makeMove('U'), level)],
                 ['D', best_move(game.makeMove('D'), level)],
                 ['L', best_move(game.makeMove('L'), level)],
                 ['R', best_move(game.makeMove('R'), level)]]
        print(moves)
        moves.sort(key=lambda x: x[1], reverse=True)
        move = moves[0]

        yield move[0]



def best_move(game: Game_IJK, level):
    level += 1

    board = game.getGame()
    player = game.getCurrentPlayer()
    deterministic = game.getDeterministic()

    # Python dictionary reminder: https://www.pythonforbeginners.com/dictionary/how-to-use-dictionaries-in-python
    points = {
        'a':0,
        'A':0,
        'b':-5,
        'B':5,
        'c':-10,
        'C':10,
        'e':-15,
        'E':15,
        'f':-20,
        'F':20,
        'g':-25,
        'G':25,
        'h':-30,
        'H':30,
        'j':-35,
        'J':35,
        'k':-1000,
        'K':1000
    }

    if player == "-":
        if level == 5:
            score = 0
            board = game.getGame()
            for r in board:
                for c in r:
                    if c in points:
                        score = points.get(c)

            return score

        return min(best_move(game.makeMove('D'), level), best_move(game.makeMove('U'), level), best_move(game.makeMove('L'), level),
                   best_move(game.makeMove('R'), level))

    if player == "+":
        if level == 5:
            score = 0
            board = game.getGame()
            for r in board:
                for c in r:
                    if c in points:
                        score = points.get(c)

            return score

        return max(best_move(game.makeMove('D'), level), best_move(game.makeMove('U'), level), best_move(game.makeMove('L'), level),
                   best_move(game.makeMove('R'), level))


