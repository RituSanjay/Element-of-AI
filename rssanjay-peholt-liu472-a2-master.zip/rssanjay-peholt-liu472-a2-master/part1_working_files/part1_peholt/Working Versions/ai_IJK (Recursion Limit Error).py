#!/usr/local/bin/python3

"""
This is where you should write your AI code!

Authors: Chang Liu/Liu472,

Based on skeleton code by Abhilash Kuhikar, October 2019
"""

from logic_IJK import Game_IJK
import random

# Suggests next move to be played by the current player given the current game
#
# inputs:
#     game : Current state of the game 
#
# This function should analyze the current state of the game and determine the 
# best move for the current player. It should then call "yield" on that move.

def next_move(game: Game_IJK)-> None:

    '''board: list of list of strings -> current state of the game
       current_player: int -> player who will make the next move either ('+') or -'-')
       deterministic: bool -> either True or False, indicating whether the game is deterministic or not
    '''

    board = game.getGame()
    player = game.getCurrentPlayer()
    deterministic = game.getDeterministic()

    # You'll want to put in your fancy AI code here. For right now this just 
    # returns a random move.

    # Reminder on sorting in Python:
    # https://stackoverflow.com/questions/409370/sorting-and-grouping-nested-lists-in-python

    ancestor = "na"

    d = best_move_min(game.makeMove('D'), ancestor)
    u = best_move_min(game.makeMove('U'), ancestor)
    l = best_move_min(game.makeMove('L'), ancestor)
    r = best_move_min(game.makeMove('R'), ancestor)

    moves = [['U', u],
             ['D', d],
             ['L', l],
             ['R', r]]
    print(moves)
    moves.sort(key=lambda x: x[1], reverse=True)
    move = moves[0]

def best_move_max(game: Game_IJK, min_ancestor):

    board = game.getGame()
    player = game.getCurrentPlayer()
    deterministic = game.getDeterministic()
    moves = []

    if "K" in board:
        return 1

    if min_ancestor == "na":
        d = best_move_min(game.makeMove('D'), "na")
        u = best_move_min(game.makeMove('U'), d)
        l = best_move_min(game.makeMove('L'), max(d,u))
        r = best_move_min(game.makeMove('R'), max(d,u,l))

        return max(d,u,l,r)

    if min_ancestor != "na":
        d = best_move_min(game.makeMove('D'), "na")
        if min_ancestor < d:
            return d

        u = best_move_min(game.makeMove('U'), d)
        if min_ancestor < max(d, u):
            return max(d, u)

        l = best_move_min(game.makeMove('L'), max(d, u))
        if min_ancestor > max(d, u, l):
            return max(d, u, l)

        r = best_move_min(game.makeMove('R'), max(d, u, l))
        return max(d, u, l, r)




def best_move_min(game: Game_IJK, max_ancestor):

    board = game.getGame()
    player = game.getCurrentPlayer()
    deterministic = game.getDeterministic()
    moves = []

    if "k" in board:
        return -1

    if max_ancestor == "na":
        d = best_move_max(game.makeMove('D'), "na")
        u = best_move_max(game.makeMove('U'), d)
        l = best_move_max(game.makeMove('L'), min(d,u))
        r = best_move_max(game.makeMove('R'), min(d,u,l))

        return min(d,u,l,r)

    if max_ancestor != "na":
        d = best_move_max(game.makeMove('D'), "na")
        if max_ancestor > d:
            return d

        u = best_move_max(game.makeMove('U'), d)
        if max_ancestor > min(d,u):
            return min(d,u)

        l = best_move_max(game.makeMove('L'), min(d, u))
        if max_ancestor > min(d,u,l):
            return min(d,u,l)

        r = best_move_max(game.makeMove('R'), min(d, u, l))
        return min(d,u,l,r)












