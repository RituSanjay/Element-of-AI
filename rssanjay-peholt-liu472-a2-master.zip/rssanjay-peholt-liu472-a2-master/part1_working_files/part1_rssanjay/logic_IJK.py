#!/usr/local/bin/python3

"""
This file implements the IJK board and rules. 
Please do not modify anything in this file.

THIS IS VERSION v2.0, updated 11/1/2019.

@author: Abhilash Kuhikar, October 2019
"""

'''
logic code inspired from https://github.com/yangshun/2048-python
'''

'''
Game API Documentation:
game.makeMove(move)->Game_IJK:
    Input argument move: one of 'U', 'L', 'R', 'D', 'S'
    Returns deepcopy of the game object after the 'move' is applied

game.printGame()->None:
    Prints the current game in user readable format

game.getGame()->List[List[int]]:
    Returns current game board as list of list of int

game.getCurrentPlayer()->int:
    Returns '+', if currentPlayer is uppercase
    Returns '-', if currentPlayer is lowercase

game.getDeterministic()->bool:
    Returns True if the game is in deterministic mode
    Returns False if the game is in non-deterministic mode

game.state()->string:
    Returns 
        C : uppercase  has won with highest tile C
        c : lowercase  has won with highest tile c
        'Tie' : game is over with a tie
        0 : game is still on
'''

import random
import copy


class InvalidMoveException(Exception):
    pass


class GameFullException(Exception):
    pass


'''Gives an object of Game_IJK with initial empty game and first player as uppercase
'''


def initialGame(size=6, player='+', deterministic=True):
    game = [[' ' for _ in range(size)] for _ in range(size)]
    game[0][0] = 'A' if player == '+' else 'a'
    return Game_IJK(game, player, deterministic)


class Game_IJK:
    def __init__(self, game, currentPlayer, deterministic):
        print("Initializing the game board...")
        self.__game = game
        self.__current_player = +1 if currentPlayer == '+' else -1
        self.__previous_game = self.__game
        self.__new_piece_loc = (0, 0)
        self.__deterministic = deterministic

    def __switch(self): #SWITCHES THE PLAYER AFTER CURRENT PLAYER'S TURN
        print("In __switch(self) function .... switching player")
        self.__current_player = -self.__current_player

    def isGameFull(self):
        print(" In isGameFull(self) function - checking if board is full")
        for i in range(len(self.__game)):         # ROWS OF MATRIX
            for j in range(len(self.__game[0])):  # COLUMNS OF MATRIX
                if self.__game[i][j] == ' ':
                    return False                  # TRAVERSE THROUGH ALL CELLS; IF ANY EMPTY SPACE EXISTS => RETURN FALSE
        return True

    def __game_state(self, mat):
        print("In __game_state(self,mat) function..........")
        #print(self)
        #print(mat)
        highest = {'+': 'A', '-': 'a'}   #INITIALLY, THE HIGHEST VALUES FOR BOTH PLAYERS IS 'a' AND 'A' - DICTIONARY
        
        # FIND THE HIGHEST POSSIBLE VALUE FOR EACH PLAYER
        for i in range(len(mat)):
            for j in range(len(mat[0])):    #AS PER THE GAME BOARD'S CURRENT STATE, CHANGE THE HIGHEST VALUES OBTAINED FOR EACH PLAYER
                if (mat[i][j]).isupper():
                    highest['+'] = chr(max(ord(mat[i][j]), ord(highest['+'])))  #chr() FUNCTION CONVERTS UNICODE NUMBERS TO CHARECTER VALUE i.e. '97' becomes 'a'
                if (mat[i][j]).islower():
                    highest['-'] = chr(max(ord(mat[i][j]), ord(highest['-'])))  #ord() FUNCTION CONVERTS CHARECTER VALUE TO UNICODE INTEGER i.e. 'a' becomes '97'
        print(highest)

        if highest['+'] == 'K' or highest['-'] == 'k' or self.isGameFull(): # CHECK IF EITHER PLAYERS HAVE REACHED 'K'
            if highest['+'].lower() != highest['-']:
                return highest['+'] if highest['+'].lower() > highest['-'] else highest['-'] # RETURN VALUE FOR PLAYER WITH HIGHER SCORE (ALPHABET)
            return 'Tie'

        return 0

    def __reverse(self, mat):   # REVERSE THE GAME BOARD
        print("In __reverse(self,mat) function..........")
        #print(self)
        #print(mat)
        new = []
        for i in range(len(mat)):
            new.append([])
            for j in range(len(mat[0])):
                new[i].append(mat[i][len(mat[0]) - j - 1])
        #print(new)
        return new

    def __transpose(self, mat):  # TRANSPOSE THE GAME BOARD
        print("In __transpose(self,mat) function..........")
        #print(self)
        #print(mat)
        new = []
        for i in range(len(mat[0])):
            new.append([])
            for j in range(len(mat)):
                new[i].append(mat[j][i])
        #print(new)
        return new

    def __cover_up(self, mat):
        print("In __cover_up(self,mat) function..........")
        #print(self)
        #print(mat)
        new = [[' ' for _ in range(len(self.__game))] for _ in range(len(self.__game))] # __game IS THE BOARD STATE
        print(new)
        done = False
        for i in range(len(self.__game)):
            count = 0
            for j in range(len(self.__game)):
                if mat[i][j] != ' ':
                    new[i][count] = mat[i][j]
                    if j != count:
                        done = True
                    count += 1
        #print(new)
        return (new, done)

    def __merge(self, mat):        # GIVEN A MOVE, MERGE THE VALUES CELLS IN THE SAME ROW/COLUMN TO GET A HIGHER VALUE IN CELL....
                                   # SORRY, DONT KNOW HOW CLEAR THIS WAS...BUT IT MAKES SENSE IN MY HEAD
        print("In __merge(self,mat) function..........")
        #print(self)
        #print(mat)
        global current_player

        done = False
        for i in range(len(self.__game)):
            for j in range(len(self.__game) - 1):
                if mat[i][j] == mat[i][j + 1] and mat[i][j] != ' ':   
                    mat[i][j] = chr(ord(mat[i][j]) + 1)  # ADD ONE TO THE CELL
                    mat[i][j + 1] = ' ' # THE ADJACENT CELL IS MADE EMPTY
                    done = True
                elif mat[i][j].upper() == mat[i][j + 1].upper() and mat[i][j] != ' ':
                    mat[i][j] = chr(ord(mat[i][j]) + 1)
                    mat[i][j] = mat[i][j].upper() if self.__current_player > 0 else mat[i][j].lower()
                    mat[i][j + 1] = ' '
                    done = True
        #print(mat)
        return (mat, done)

    def __up(self, game):
        print("up")
        # return matrix after shifting up
        game = self.__transpose(game)       # TRANSPOSE THE BOARD TO....
        print(game)
        game, done = self.__cover_up(game)  # COVER UP
        print(game)
        temp = self.__merge(game)           # MERGE
        print(temp)
        game = temp[0]
        print(game)
        done = done or temp[1]
        game = self.__cover_up(game)[0]     # COVER UP
        print(game)
        game = self.__transpose(game)       # TRANSPOSE BACK
        print(game)
        if done == True:
            self.__game = copy.deepcopy(game)
        return (game, done)

    def __down(self, game):
        # print("down")
        game = self.__reverse(self.__transpose(game))
        game, done = self.__cover_up(game)
        temp = self.__merge(game)
        game = temp[0]
        done = done or temp[1]
        game = self.__cover_up(game)[0]
        game = self.__transpose(self.__reverse(game))
        if done == True:
            self.__game = copy.deepcopy(game)
        return (game, done)

    def __left(self, game):
        # print("left")
        # return matrix after shifting left
        game, done = self.__cover_up(game)
        temp = self.__merge(game)
        game = temp[0]
        done = done or temp[1]
        game = self.__cover_up(game)[0]
        if done == True:
            self.__game = copy.deepcopy(game)
        return (game, done)

    def __right(self, game):
        # print("right")
        # return matrix after shifting right
        game = self.__reverse(game)
        game, done = self.__cover_up(game)
        temp = self.__merge(game)
        game = temp[0]
        done = done or temp[1]
        game = self.__cover_up(game)[0]
        game = self.__reverse(game)
        if done == True:
            self.__game = copy.deepcopy(game)
        return (game, done)

    def __skip(self):
        x, y = self.__new_piece_loc
        self.__game[x][y] = self.__game[x][y].swapcase()

    '''
    Expose this method to client to print the current state of the board
    '''

    def printGame(self):   # PRINT THE BOARD STATE
        str_game = [['______' for _ in range(len(self.__game))] for _ in range(len(self.__game))]

        for i in range(len(self.__game)):
            for j in range(len(self.__game)):
                str_game[i][j] = "_" + self.__game[i][j] + "_"

        for i in range(len(self.__game)):
            print("|".join(str_game[i]))
        print("\n")

    def __add_piece(self):
        print("In __add_piece(self) function")
        if self.__deterministic:
            print("Adding the next A or 'a' for the deterministic game")
            for i in range(len(self.__game)):
                for j in range(len(self.__game)):
                    if self.__game[i][j] == ' ':
                        self.__game[i][j] = 'A' if self.__current_player > 0 else 'a'   #IN DETERMINISTIC APPROACH, THE FIRST EMPTY POSITION IS CHOSEN
                        self.__new_piece_loc = (i, j)    # __new_piece_loc is the new position of the new added A or a
                        return
        else:
            print("Adding the next A or 'a' for the non-deterministic game")
            open = []
            for i in range(len(self.__game)):
                for j in range(len(self.__game)):
                    if self.__game[i][j] == ' ':
                        open += [(i, j), ]   # open STORES A LIST OF ALL EMPTY SPACES ON THE BOARD

            if len(open) > 0:
                r = random.choice(open) # CHOOSE A POSITION ON THE BOARD RANDOMPLE FROM open
                self.__game[r[0]][r[1]] = 'A' if self.__current_player > 0 else 'a'
                self.__new_piece_loc = r

    def makeMove(self, move):               # BASED ON THE CHOICE GIVEN, THE REQUIRED MOVE FUNCTION IS CALLED
        if move not in ['U', 'L', 'D', 'R']:
            raise InvalidMoveException

        self.__previous_game = self.__game
        if move == 'L':
            self.__left(self.__game)
        if move == 'R':
            self.__right(self.__game)
        if move == 'D':
            self.__down(self.__game)
        if move == 'U':
            self.__up(self.__game)
        if move == 'S':
            self.__skip()

        '''
        Switch player after the move is done
        '''
        self.__switch()   # SWITCH THE PLAYER
        if move != 'S':
            self.__add_piece()  # ADD THE NEXT 'A' OR 'a'
        # self.printGame()

        return copy.deepcopy(self)  # deepcopy() MAKES THE COPY THE ORIGINAL

    def getDeterministic(self):
        return self.__deterministic

    def getGame(self):   # RETURN THE CURRENT STATE OF THE GAME
        return copy.deepcopy(self.__game)

    '''player who will make the next move'''

    def getCurrentPlayer(self):   # RETURN THE CURRENT PLAYER
        return '+' if self.__current_player > 0 else '-'

    ''' '+' : '+' has won
       '-1' : '-' has won
       '' : Game is still on
    '''

    def state(self):       # RETURN THE STATE OF TEH BOARD
        return self.__game_state(self.__game)

