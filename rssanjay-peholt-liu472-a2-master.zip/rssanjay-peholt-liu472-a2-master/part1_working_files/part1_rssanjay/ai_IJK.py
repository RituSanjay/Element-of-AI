#!/usr/local/bin/python3

"""
This is where you should write your AI code!

Authors: Ritu Sanjay - rssanjay

Based on skeleton code by Abhilash Kuhikar, October 2019
"""

from logic_IJK import Game_IJK
import random
import math

# Suggests next move to be played by the current player given the current game
#
# inputs:
#     game : Current state of the game 
#
# This function should analyze the current state of the game and determine the 
# best move for the current player. It should then call "yield" on that move.

def transpose(mat):
    new = []
    for i in range(len(mat[0])):
        new.append([])
        for j in range(len(mat)):
            new[i].append(mat[j][i])
    #print(new)
    return new

def cover_up(board):
    new = [[' ' for _ in range(len(self.__game))] for _ in range(len(self.__game))] # __game IS THE BOARD STATE
    #print(new)
    done = False
    for i in range(len(self.__game)):
        count = 0
        for j in range(len(self.__game)):
            if mat[i][j] != ' ':
                new[i][count] = mat[i][j]
                if j != count:
                    done = True
                count += 1
    #print(new)
    return (new, done)

def merge(board):
    #global current_player
    done = False
    for i in range(len(self.__game)):
        for j in range(len(self.__game) - 1):
            if mat[i][j] == mat[i][j + 1] and mat[i][j] != ' ':
                mat[i][j] = chr(ord(mat[i][j]) + 1)  # ADD ONE TO THE CELL
                mat[i][j + 1] = ' ' # THE ADJACENT CELL IS MADE EMPTY
                done = True
            elif mat[i][j].upper() == mat[i][j + 1].upper() and mat[i][j] != ' ':
                mat[i][j] = chr(ord(mat[i][j]) + 1)
                mat[i][j] = mat[i][j].upper() if self.__current_player > 0 else mat[i][j].lower()
                mat[i][j + 1] = ' '
                done = True
    #print(mat)
    return (mat, done)

def reverse(board):

def move_up(board):
    game = transpose(board)
    game, done = board.__cover_up(game)
    temp = board.__merge(game)
    game = temp[0]
    done = done or temp[1]
    game = board.__cover_up(game)[0]
    game = board.__transpose(game)   
    # FIND THE SCORE FOR THIS MOVE
    sc = score(game)
    b=board.__add_piece(game)
    return b,sc

def move_down(board):
    game = board.__reverse(self.__transpose(board))
    game, done = board.__cover_up(game)
    temp = board.__merge(game)
    game = temp[0]
    done = done or temp[1]
    game = board.__cover_up(game)[0]
    game = board.__transpose(self.__reverse(game))
    # FIND THE SCORE FOR THIS MOVE
    sc = score(game)
    b=board.__add_piece(game)
    return b,sc

def move_left(board):
    game, done = board.__cover_up(board)
    temp = board.__merge(game)
    game = temp[0]
    done = done or temp[1]
    game = board.__cover_up(game)[0]
    # FIND THE SCORE FOR THIS MOVE
    sc = score(game)
    b=board.__add_piece(game)
    return b,sc

def move_right(board):
    game = board.__reverse(board)
    game, done = board.__cover_up(game)
    temp = board.__merge(game)
    game = temp[0]
    done = done or temp[1]
    game = board.__cover_up(game)[0]
    game = board.__reverse(game)
    # FIND THE SCORE FOR THIS MOVE
    sc = score(game)
    b=board.__add_piece(game)
    return b,sc

def next_move(game: Game_IJK)-> None:
    print("I have started the game - ai ")

    '''board: list of list of strings -> current state of the game
       current_player: int -> player who will make the next move either ('+') or -'-')
       deterministic: bool -> either True or False, indicating whether the game is deterministic or not
    '''

    board = game.getGame()
    print(board)
    print(type(board))
    current_player = game.getCurrentPlayer()
    print(current_player)
    deterministic = game.getDeterministic()
    print(deterministic)
    alpha=math.inf
    beta=math.inf

    # You'll want to put in your fancy AI code here. For right now this just 
    # returns a random move.
    print("Lets go with the fancy code now")

    # HERE GOES MY FANCY CODE...
    # DEPENDS ON THE AI BEING '+' OR'-'
    # DO NOT GENERATE ENTIRE GAME TREE - START FROM THE GIVEN STATE OF BOARD AND GENERATE NODES UPTO A DEPTH OF 2
    # REQUIREMENTS:
      # STATE OF BOARD AT THE START OF EACH TURN - given by the variable 'board' - this will be the root node.
      # SUCCESSOR FUNCTION : WILL ALWAYS BE 'U', 'D', 'L', OR 'R'
      # TERMINAL STATE
      # UTILITY FUNCTION - VALUE OF GOING WITH ANY MOVE

    # TRY 1 : USING THE __game_state(self,mat) get the score based on  the alphabet
     #score = {'a':-5, 'A':5,'b':-10,'B':10,'c':-15,'C':15,
        #'e':-20,'E':20, 'f':-25,'F':25,'g':-30, 'G':30,
        #'h':-35,'H':35,'j':-40,'J':40, 'k':-45,'K':45}

    # CALL A FUNCTION TO GENERATE A GAME TREE UPTO DEPTH 2
      # THIS FUNCTION CALLS __UP(), __DOWN(), __LEFT() AND __RIGHT()
      # FOR EACH MOVE, CALL THE EVALUATE FUNCTION

    # FIND BEST POSSIBLE MOVE

    if current_player=='+': # SUPPOSING THAT THE AI IS MAX
        print(" find the best possible move")
        MIN=[]
        min_score=[]
        u,up_score=move_up(board)
        print("up")
        MIN.append(u)
        min_score.append(up_score)
        d,down_score=move_down(board)
        MIN.append(d)
        min_score.append(down_score)
        l,left_score=move_left(board)
        MIN.append(l)
        min_score.append(left_score)
        r,right_score=move_right(board)
        MIN.append(r)
        min_score.append(right_score)

        # FOR EACH BOARD STATE IN 'MIN'
        VAL_PROP_FROM_L2=[]
        print("VAL_PROP_FROM_L2: ")
        print(VAL_PROP_FROM_L2)
        for b in MIN:
            # NOW GENERATE THE POSSIBLE MOVES 
            temp=[]
            temp_score=[]
            temp_up,temp_up_score=move_up(b)
            temp.append(temp_up)
            temp_score.append(temp_up_score)
            temp_down,temp_down_score=move_down(b)
            temp.append(temp_down)
            temp_score.append(temp_down_score)
            temp_left,temp_left_score=move_left(b)
            temp.append(temp_left)
            temp_score.append(temp_left_score)
            temp_right,temp_right_score=move_right(b)
            temp.append(temp_right)
            temp_score.append(temp_right_score)
            VAL_PROP_FROM_L2.append(min(temp_score))

        VAL_PROP_TO_L1=max(VAL_PROP_FROM_L2)
        index_max = max(xrange(len(VAL_PROP_FROM_L2)), key=VAL_PROP_FROM_L2.__getitem__)
        print("VAL_PROP_TO_L1: ")
        print(VAL_PROP_TO_L1)
        print("Index of val:")
        print(index_max)

        if index_max==0:
            move='U'
        elif index_max==1:
            move='D'
        elif index_max==2:
            move='L'
        elif index_max==3:
            move='R'

        return move

    if current_player=='-': # SUPPOSING THAT THE AI IS MIN
        MAX=[]
        max_score=[]
        up,up_score=up(board)
        MAX.append(up)
        max_score.append(up_score)
        down,down_score=down(board)
        MAX.append(down)
        max_score.append(down_score)
        left,left_score=left(board)
        MAX.append(left)
        max_score.append(left_score)
        right,right_score=right(board)
        MAX.append(right)
        max_score.append(right_score)

        # FOR EACH BOARD STATE IN 'MIN'
        VAL_PROP_FROM_L2=[]
        
        for board in MAX:
            # NOW GENERATE THE POSSIBLE MOVES 
            temp=[]
            temp_score=[]
            temp_up,temp_up_score=up(b)
            temp.append(temp_up)
            temp_score.append(temp_up_score)
            temp_down,temp_down_score=down(b)
            temp.append(temp_down)
            temp_score.append(temp_down_score)
            temp_left,temp_left_score=left(b)
            temp.append(temp_left)
            temp_score.append(temp_left_score)
            temp_right,temp_right_score=right(b)
            temp.append(temp_right)
            temp_score.append(temp_right_score)
            VAL_PROP_FROM_L2.append(max(temp_score))

        VAL_PROP_TO_L1=min(VAL_PROP_FROM_L2)
        index_min = min(xrange(len(VAL_PROP_FROM_L2)), key=VAL_PROP_FROM_L2.__getitem__)

        if index_min==0:
            move='U'
        elif index_min==1:
            move='D'
        elif index_min==2:
            move='L'
        elif index_min==3:
            move='R'
        return move

    #yield random.choice(['U', 'D', 'L', 'R'])



def score(board,alpha,beta,depth,current_player):
    # CREATE A SCORE DICTIONARY
    score = {'a':-5, 'A':5,'b':-10,'B':10,'c':-15,'C':15,
        'e':-20,'E':20, 'f':-25,'F':25,'g':-30, 'G':30,
        'h':-35,'H':35,'j':-40,'J':40, 'k':-45,'K':45}
    highest = {'+': 'A', '-': 'a'}
    mat=board

    # RETURN THE HIGHEST VALUED CELL ON THE BOARD
    #game.__game_state(self, mat)
    for i in range(len(mat)):
            for j in range(len(mat[0])):    #AS PER THE GAME BOARD'S CURRENT STATE, CHANGE THE HIGHEST VALUES OBTAINED FOR EACH PLAYER
                if (mat[i][j]).isupper():
                    highest['+'] = chr(max(ord(mat[i][j]), ord(highest['+'])))  #chr() FUNCTION CONVERTS UNICODE NUMBERS TO CHARECTER VALUE i.e. '97' becomes 'a'
                if (mat[i][j]).islower():
                    highest['-'] = chr(max(ord(mat[i][j]), ord(highest['-'])))  #ord() FUNCTION CONVERTS CHARECTER VALUE TO UNICODE INTEGER i.e. 'a' becomes '97'

    if current_player == 1:
        # something
        for key in score:
            if highest['+']==key:
                return score[key]
    elif current_player == -1:
        # another something
        for key in score:
            if highest['-']==key:
                return score[key]
    


    

    






    

