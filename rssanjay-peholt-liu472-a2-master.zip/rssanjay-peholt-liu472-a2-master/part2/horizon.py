#!/usr/local/bin/python3
#
# Authors: Chang Liu/LIU472
#
# Mountain ridge finder
# Based on skeleton code by D. Crandall, Oct 2019
#

from PIL import Image
from numpy import *
from scipy.ndimage import filters
import sys
import imageio
import math

# calculate "Edge strength map" of an image
#
def edge_strength(input_image):
    grayscale = array(input_image.convert('L'))
    filtered_y = zeros(grayscale.shape)
    filters.sobel(grayscale,0,filtered_y)
    return sqrt(filtered_y**2)

# draw a "line" on an image (actually just plot the given y-coordinates
#  for each x-coordinate)
# - image is the image to draw on
# - y_coordinates is a list, containing the y-coordinates and length equal to the x dimension size
#   of the image
# - color is a (red, green, blue) color triple (e.g. (255, 0, 0) would be pure red
# - thickness is thickness of line in pixels
#
def draw_edge(image, y_coordinates, color, thickness):
    for (x, y) in enumerate(y_coordinates):
        for t in range( int(max(y-int(thickness/2), 0)), int(min(y+int(thickness/2), image.size[1]-1 )) ):
            image.putpixel((x, t), color)
    return image


def get_emission(n, m, row, col):
    emission = zeros(shape=(n, m))
    for i in range(m):
        if i == col:
            emission[:, col] = zeros(n)
            emission[row, col] = 1
        else:
            emission[:, i] = soft_max(edge_strength[:, i])
    return emission


def get_transition(n):
    transition = zeros(shape=(n, n))
    for i in range(n):
        transition[i, :] = reverse(n, i)
    return transition


def get_viterbi(n, m, emiss, trans):
    viterbi = zeros(shape=(n, m))
    for i in range(n):
        for j in range(m):
            if j == 0:
                viterbi[i, j] = log(1/n) + emiss[i, j]
            else:
                p = emiss[i, j] + max([viterbi[k, j-1]+trans[k, i] for k in range(n)])
                viterbi[i, j] = p
    return viterbi


# takes the strength map
def get_edge(edge_strength):
    """Simple"""
    res = []
    n = len(edge_strength[0, :])
    for i in range(n):
        temp = clean_check(edge_strength[:n, i])
        res.append(argmax(edge_strength[:, i]))
    res_simple = res
    """Viterbi"""
    n, m = len(edge_strength), len(edge_strength[0])
    # getting the emission layer
    emission_viterbi = get_emission(n, m, -1, -1)
    emission_human = get_emission(n, m, gt_row, gt_col)
    # getting the transition layer
    transition = get_transition(n)
    # generate viterbi
    viterbi_viterbi = get_viterbi(n, m, emission_viterbi, transition)
    viterbi_human = get_viterbi(n, m, emission_human, transition)

    res_viterbi = argmax(viterbi_viterbi, axis=0)
    res_human = argmax(viterbi_human, axis=0)
    return res_simple, res_viterbi, res_human



# get the top ones that are closest to the sky
# with assumption that sky has close to 0 gradient
# aware of the situation that clouds can have strong gradient..but...
def clean_check(gradients):
    temp = gradients
    n = 30
    # get top n most possible ones
    not_sky = temp.argsort()[-n:][::-1]
    temp2 = []
    temp3 = []
    # get a list of top n gradients and sort their index based on gradient
    for i in range(len(gradients)):
        if i in not_sky:
            temp2.append(gradients[i])
            temp3.append(i)
    # sorted_gradient_index = [x for _, x in sorted(zip(temp2, temp3))]
    # calculate number of large gradient distributed below this point
    for i in range(len(gradients)):
        if i in not_sky:
            gradients[i] = n - temp3.index(i)
        else:
            gradients[i] = 0
    return gradients


def soft_max(x):
    return log10((x+1/len(x))/(x.sum()+1))


def smooth_huh():
    pass

def reverse(x, y):
    temp1 = array([abs(z-y) for z in range(x)])
    temp2 = array([pow((max(temp1)+1 - z), 2) for z in temp1])
    temp3 = log10(temp2/temp2.sum())
    return temp3


# main program
if __name__ == '__main__':
    (input_filename, gt_row, gt_col) = sys.argv[1:]
    # load in image
    input_image = Image.open(input_filename)
    # compute edge strength mask
    edge_strength = edge_strength(input_image)
    p = uint8(255 * edge_strength / (amax(edge_strength)))
    imageio.imwrite('edges.jpg', p)
    ridge_simple, ridge_viterbi, ridge_human = get_edge(edge_strength)
    # output answer, simple blue, viterbi red, human green, (R,G,B)
    imageio.imwrite("output_simple.jpg", draw_edge(input_image, ridge_simple, (0, 0, 255), 5))
    imageio.imwrite("output_map.jpg", draw_edge(input_image, ridge_viterbi, (255, 0, 0), 5))
    imageio.imwrite("output_human.jpg", draw_edge(input_image, ridge_human, (0, 255, 0), 5))
    # i = 2
    # input_filename, gt_row, gt_col = "mountain%d.jpg" % i, 100, 10
    # # load in image
    # input_image = Image.open(input_filename)
    # # compute edge strength mask
    # edge_strength = edge_strength(input_image)
    # p = uint8(255 * edge_strength / (amax(edge_strength)))
    # imageio.imwrite('edges%d.jpg' % i, p)
    # ridge_simple, ridge_viterbi, ridge_human = get_edge(edge_strength)
    # # output answer, simple blue, viterbi red, human green, (R,G,B)
    # imageio.imwrite("output_simple_%d.jpg" % i, draw_edge(input_image, ridge_simple, (0, 0, 255), 5))
    # imageio.imwrite("output_map_%d.jpg" % i, draw_edge(input_image, ridge_viterbi, (255, 0, 0), 5))
    # imageio.imwrite("output_human_%d.jpg" % i, draw_edge(input_image, ridge_human, (0, 255, 0), 5))
