# Assignment 2: Part 2
## The Horizon Finding Problem
![the bests](output7.jpg)![the bests](output2.jpg)![the bests](output3.jpg)

![the bests](output5.jpg)![the bests](output6.jpg)![the bests](output1.jpg)

The concept behind is to get the point for each column of picture
with largest possible gradient while keeping the line smooth and close to or actually lies on the horizon.
To not make this problem any more complicated, the approach is only utilizing the gradient graph but not the RGB file.
With these said, these are the three approach implemented in this question:
1. Simple bayes that solely base on gradient for each column under consideration of sky/ground ratio. This is with the assumption that sky are mostly clear(with lower gradients).
2. Implement the Viterbi algorithm on top of the first step, which builds up relationship between neighboring horizon predictions. Other than that, give more weight on the pixels that are closer to the last prediction so to increase the chance of getting a smooth line.
3. With the help of ground truth from human input, we can be more certain about certain part of the prediction and hopefully help the overall performance.
### Coding
Since we are given the gradient graph, everything will be based on the data "edge_strength."

This is the main part of the code which generates ridge_simple, ridge_viterbi, and ridge_human. Each corresponding to the sub-problems defined above.
The results are displayed in original file by plotting colored dots which forms a line.
```python
ridge_simple, ridge_viterbi, ridge_human = get_edge(edge_strength)
# output answer, simple blue, viterbi red, human green, (R,G,B)
imageio.imwrite("output_simple.jpg", draw_edge(input_image, ridge_simple, (0, 0, 255), 5))
imageio.imwrite("output_map.jpg", draw_edge(input_image, ridge_viterbi, (255, 0, 0), 5))
imageio.imwrite("output_human.jpg", draw_edge(input_image, ridge_human, (0, 255, 0), 5))
```
Other functions includes:
```python
clean_check()
soft_max()
reverse()
get_emission()
get_transition()
get_viterbi()
smooth_huh()
```
Main procedures are divided into two parts:
- First part is the simple output, which is an implementation of the below graph. It calculate the probability for each column base on the the sky/ground ratio and gradient value.

![simple bayes](part1.png)<!-- .element height="20%" width="20%" -->
- Second part is implemented with the Viterbi algorithm. It first create the emission matrix, then the transition matrix
, and then calculate the viterbi base on emission and transition. And the algorithm would also return the viterbi with human input ground truth by changing the emission layer. The process follows the below graph.

![Viterbi](part2.png)<!-- .element height="20%" width="20%" -->

##Problems encountered
- The sky is actually not clean, at all! Some part of sky can have really large gradient that is larger than the ground truth horizon's gradient.
- It is hard to balance between how smooth the horizon is and how close it is to the ground truth since other things other than mountains can also form a horizon.
- Human input doesn't really change the result since its only one pixel.
