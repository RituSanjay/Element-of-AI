# Assignment 2

Please see individual README files for each part of the assignment in their respective folders.
