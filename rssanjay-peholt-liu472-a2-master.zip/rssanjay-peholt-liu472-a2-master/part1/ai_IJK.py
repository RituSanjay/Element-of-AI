#!/usr/local/bin/python3

"""
This is where you should write your AI code!

Authors: Peter Holt/peholt,

Based on skeleton code by Abhilash Kuhikar, October 2019
"""

from logic_IJK import Game_IJK
import random, copy

# Suggests next move to be played by the current player given the current game
#
# inputs:
#     game : Current state of the game 
#
# This function should analyze the current state of the game and determine the 
# best move for the current player. It should then call "yield" on that move.

def next_move(game: Game_IJK)-> None:

    '''board: list of list of strings -> current state of the game
       current_player: int -> player who will make the next move either ('+') or -'-')
       deterministic: bool -> either True or False, indicating whether the game is deterministic or not
    '''

    board = game.getGame()
    player = game.getCurrentPlayer()
    deterministic = game.getDeterministic()
    #print(board)
    # You'll want to put in your fancy AI code here. For right now this just

    level = 0
    ancestor = "na"
    print("Starting player: ", player)

    # Python dictionary reminder: https://www.pythonforbeginners.com/dictionary/how-to-use-dictionaries-in-python
    if player == "+":
        values = {
            'a': 0, 'A': 0, 'b': -5, 'B': 50, 'c': -10, 'C': 10, 'e': -15, 'E': 15, 'f': -20, 'F': 20, 'g': -25,
            'G': 25, 'h': -30, 'H': 30, 'j': -35, 'J': 35, 'k': -1000, 'K': 1000
        }
    if player == "-":
        values = {
            'a': 0, 'A': 0, 'b': 5, 'B': -5, 'c': 10, 'C': -10, 'e': 15, 'E': -15, 'f': 20, 'F': -20, 'g': 25,
            'G': -25, 'h': 30, 'H': -30, 'j': 35, 'J': -35, 'k': 1000, 'K': -1000
        }

    # Reminder on copying objects in Python:
    # https://docs.python.org/2/library/copy.html
    game_d = copy.deepcopy(game)
    game_u = copy.deepcopy(game)
    game_l = copy.deepcopy(game)
    game_r = copy.deepcopy(game)

    d = best_move_min(game_d.makeMove('D'), ancestor, level, values)
    u = best_move_min(game_u.makeMove('U'), ancestor, level, values)
    l = best_move_min(game_l.makeMove('L'), ancestor, level, values)
    r = best_move_min(game_r.makeMove('R'), ancestor, level, values)

    moves = [['U', u],
             ['D', d],
             ['L', l],
             ['R', r]]
    print("Possible moves: ", moves)
    print("")

    # Reminder on sorting in Python:
    # https://stackoverflow.com/questions/409370/sorting-and-grouping-nested-lists-in-python
    moves.sort(key=lambda x: x[1], reverse=True)
    move = moves[0]

    return move[0]

def best_move_max(game: Game_IJK, min_ancestor, level, values):
    level += 1
    board = game.getGame()
    #print("level", level)
    #print("max player:", game.getCurrentPlayer())

    # Reminder on copying objects in Python:
    # https://docs.python.org/2/library/copy.html
    game_d = copy.deepcopy(game)
    game_u = copy.deepcopy(game)
    game_l = copy.deepcopy(game)
    game_r = copy.deepcopy(game)

    if level == 3:
        score = 0
        for r in board:
            for c in r:
                if c in values:
                    score += values.get(c)

        return score - level

    if min_ancestor == "na":

        d = best_move_min(game_d.makeMove('D'), "na", level, values)
        u = best_move_min(game_u.makeMove('U'), d, level, values)
        l = best_move_min(game_l.makeMove('L'), max(d,u), level, values)
        r = best_move_min(game_r.makeMove('R'), max(d,u,l), level, values)

        return max(d,u,l,r)

    if min_ancestor != "na":
        d = best_move_min(game_d.makeMove('D'), "na", level, values)
        if min_ancestor < d:
            #print("Pruning")
            return d

        u = best_move_min(game_u.makeMove('U'), d, level, values)
        if min_ancestor < max(d, u):
            #print("Pruning")
            return max(d, u)

        l = best_move_min(game_l.makeMove('L'), max(d, u), level, values)
        if min_ancestor > max(d, u, l):
            #print("Pruning")
            return max(d, u, l)

        r = best_move_min(game_r.makeMove('R'), max(d, u, l), level, values)

        return max(d, u, l, r)




def best_move_min(game: Game_IJK, max_ancestor, level, values):
    level += 1
    board = game.getGame()
    #print("level", level)
    #print("min player:", game.getCurrentPlayer())

    # Reminder on copying objects in Python:
    # https://docs.python.org/2/library/copy.html
    game_d = copy.deepcopy(game)
    game_u = copy.deepcopy(game)
    game_l = copy.deepcopy(game)
    game_r = copy.deepcopy(game)

    if level == 3:
        score = 0
        for r in board:
            for c in r:
                if c in values:
                    score += values.get(c)

        return score - level

    if max_ancestor == "na":

        d = best_move_max(game_d.makeMove('D'), "na", level, values)
        u = best_move_max(game_u.makeMove('U'), d, level, values)
        l = best_move_max(game_l.makeMove('L'), min(d,u), level, values)
        r = best_move_max(game_r.makeMove('R'), min(d,u,l), level, values)

        return min(d,u,l,r)

    if max_ancestor != "na":
        d = best_move_max(game_d.makeMove('D'), "na", level, values)
        if max_ancestor > d:
            #print("Pruning")
            return d

        u = best_move_max(game_u.makeMove('U'), d, level, values)
        if max_ancestor > min(d,u):
            #print("Pruning")
            return min(d,u)

        l = best_move_max(game_l.makeMove('L'), min(d, u), level, values)
        if max_ancestor > min(d,u,l):
            #print("Pruning")
            return min(d,u,l)

        r = best_move_max(game_r.makeMove('R'), min(d, u, l), level, values)

        return min(d,u,l,r)





