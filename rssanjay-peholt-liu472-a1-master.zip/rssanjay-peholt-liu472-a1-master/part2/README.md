# Report for Route Finding

We are given with two files that contains city names, how each city is connected(diatance, speed limit, 
highway), and gps locations for most of them.
And our task is to find the most efficient route(time, distance, segments, mpg) between two cities.

## Basic Approach

To solve this problem, I used A* search algorithm with start city as starting state, end city as goal state,
and measurements like time, distance, segments, mpg as edge weights. Starting from the start state, 
each time the algorithm update all neighboring(connected) cities' scores and set previous city as the 
current city if a lower cost is found between the current pair. And it picks the city with lowest potential
total cost as the next state/city. It stops when reaching the goal state/city and returns the route.

I have used a dictionary to store cities as keys, 
and defined each state(city) to hold four properties: 
```
{city: g_score, h_score, f_score, prev_city}
```
Where prev_city stores the previous city, g_score is the actual cost to go from prev_city to city, 
h_score is the estimate cost from city to the goal city. f_score is the sum of g and h, it dete

### Heuristic functions 
This is the main heuristic function:
```python
def heuristic(a,b,cost):
    return h_score base on cost-function given
```
Below are the functions that calculate h_score for each of the cost functions:

*each with an argument for why it is admissible
```python
def estimate_dist(a,b):      
    return the distance between two cities based on gps
```
The manhattan distance between two point is always less than or equal to actual distance required to travel.
```python
def estimate_time(a,b):      
    return estimated time using estimated speed and gps_dist
```
Always take the highest speed limit so to return a shorter(or equal) time than actual time needed. 
```python
def estimate_turns(a,b):     
    return estimated turns left to reach end city
```
This one is based on distance and length of the longest segment,
 so it always return a # that is less than or equal to the actual turns needed.
```python
def estimate_gallon(a,b)    
    return estimated gallon using best mpg and estimated dist
```
The function of calculating mpg has a local maximum when 
speed_limit = 30, and decrease further away from it. 
Thus, I always take the speed that produce the highest mpg and lowest gallon cost overall.

*All speed-limits falls into the range [0,130]
![MPG graph](mpg.png)<!-- .element height="50%" width="50%" -->

 ###Problems Encountered
 
 * Bidirectional documentation in 'road-segments.txt'---(*using dictionary to store data) 
 
    - Tried to use city1city2 as keys and use "try: exception:" to handle this by checking both 'city1city2' 
    and 'city2city1' but didn't work very well.
    - Then I used both 'city1city2' and 'city2city1' as keys to store the same info, which worked well.
 * Non-existing GPS
 
    - Using neighboring cities that has gps to get a weighted average gps 
    based on how far it is from the current city.
 * Measuring MPG
 
    - Couldn't figure out how to measure mpg since it's solely based on the speed limit. 
    Getting any speed using info from neighboring connections can result in potential inadmissible results.
     In the end, I went for a different approach by calculating Gallons needed by GPS_distance/Highest_MPG_Possible.

##Citation
* [A* Pathfinding Algorithm](https://www.youtube.com/watch?v=eSOJ3ARN5FM) 
Took Idea from the video and implemented A* search algorithm

##Test Cases
```python
route.py Bloomington,_Indiana Indianapolis,_Indiana segments
route.py Bloomington,_Indiana Indianapolis,_Indiana distance
route.py Bloomington,_Indiana Indianapolis,_Indiana time
route.py Bloomington,_Indiana Indianapolis,_Indiana mpg
```
##List of Variables & Functions Created
```python
gps {'city':[x, y]}                                                  where [x, y] are coordinates and int
city_map  {'city':['city1', 'city2', 'city3', ...]}                  city and it's neighbors
city_connections {'city1city2':[distance, speed limit, 'road name']} where distance and speed limit are int
```

```python
dist(a,b)               return the distance between two "Neighboring" cities(edge length)
helper_gps(x)           return the gps of a city
speed_limit(a,b)        return the speed_limit between two city
time(a,b)               return time needed between two "Neighboring" cities
mpg(a,b)                return real mpg between two cities
turns(route)            return turns made

estimate_dist(a,b)      return the distance between any two cities based on gps
estimate_time(a,b)      return estimated time using estimated speed and gps_dist
estimate_gallon(a,b)    return estimated gallon using best mpg and estimated dist
estimate_turns(a,b)     return estimated turns left to reach end city

neighbours(a)           return neighboring cities of city
g_score(a,b,cost)       return g score base on cost-function given
heuristic(a,b,cost)     return h score base on cost-function given
prefix(route)           return [total-segments] [total-miles] [total-hours] [total-gas-gallons]
a_star(a,b,cost)        return Solution
```