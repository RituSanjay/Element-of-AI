#!/usr/local/bin/python3

# put your routing program here!
# Code by: CHANG LIU/LIU472

import sys

################ Citation #####################
# https://www.youtube.com/watch?v=eSOJ3ARN5FM #
# Took idea from video and implemented A*     #
###############################################
'''
/////We have the following data variables:

gps {'city':[x, y]} where [x, y] are coordinates and float
city_map  {'city':['city1', 'city2', 'city3', ...]}
city_connections {'city1city2':[distance, speed limit, 'road name']} where distance and speed limit are int


/////And we have the following functions:

dist(a,b)               return the distance between two "Neighboring" cities(edge length)
helper_gps(x)           return the gps of a city
speed_limit(a,b)        return the speed_limit between two city
time(a,b)               return time needed between two "Neighboring" cities
mpg(a,b)                return real mpg between two cities
turns(route)            return turns made

estimate_dist(a,b)      return the distance between any two cities based on gps
estimate_time(a,b)      return estimated time using estimated speed and gps_dist
estimate_gallon(a,b)    return estimated gallon using best mpg and estimated dist
estimate_turns(a,b)     return estimated turns left to reach end city

neighbours(a)           return neighboring cities of city
g_score(a,b,cost)       return g score base on cost-function given
heuristic(a,b,cost)     return h score base on cost-function given
prefix(route)           return [total-segments] [total-miles] [total-hours] [total-gas-gallons]
a_star(a,b,cost)        return Solution

'''


# read words of each line
def help_read(filename):
    with open(filename, "r") as f:
        return [[word for word in line.split(" ")] for line in f.read().splitlines()]


# take file road-segments
# returns
# res1 as{city:[cities]}
# res2 as {"city1city2":[distance, speed limit, road name]}
def read_citymap(filename):
    data = help_read(filename)
    res1 = {}
    res2 = {}
    for x in data:
        # reading in using first city as keys
        if x[0] not in res1:
            res1[x[0]] = [x[1]]
        else:
            res1[x[0]].append(x[1])
        # reading in using second city as keys
        if x[1] not in res1:
            res1[x[1]] = [x[0]]
        else:
            res1[x[1]].append(x[0])
        # reading in using city1city2 as keys
        if x[0] + x[1] not in res2:
            res2[x[0] + x[1]] = [int(x[2]), int(x[3]), x[4]]
        # reading in using city2city1 as keys
        if x[1] + x[0] not in res2:
            res2[x[1] + x[0]] = [int(x[2]), int(x[3]), x[4]]
    return res1, res2


# return
# res as {city:[x, y]} where gps = [x, y]
def read_gps(filename):
    data = help_read(filename)
    res = {}
    for x in data:
        res[x[0]] = [float(x[1]), float(x[2])]
    return res


# return distance between two cities
# Note: here is not the distance between two gps
def dist(a, b):
    return city_connections[a + b][0]


# this is to help with the situation where gps for this city is not recorded
def helper_gps(x):
    try:
        return gps[x]
    except KeyError:
        # getting neighboring cities that has gps
        temp = [y for y in city_map[x] if y in gps]
        # if i this city is alone, return False to let heuristic return h(s) = 0
        """This only happens when all of the city's neighbors has no gps"""
        if not temp:
            return False
        # if it has only one neighbor, take that neighbor's gps
        elif len(temp) == 1:
            return gps[temp[0]]
        else:
            # if it has more than one neighbors, we continue using weight
            # getting distances between x and its neighbors as weight
            weights = []
            for i in range(len(temp)):
                weights.append(dist(x, temp[i]))
            # turn temp into neighboring cities' gps
            temp = [gps[t] for t in temp]
            # normalize weights
            small = min(weights)
            for i in range(len(weights)):
                weights[i] = weights[i]/small
            # computing gps for x(which has no gps data)
            latitude = sum([temp[i][0]/weights[i] for i in range(len(temp))])/len(temp)
            longitude = sum([temp[i][1]/weights[i] for i in range(len(temp))])/len(temp)
            return latitude, longitude
    except:
        print("helper_gps didn't work as it should")


# distance between two cities(gps location),
# if there is no gps location recorded,
# we get the average of it's neighbor's gps using distances as weights.
def estimate_dist(a, b):
    a = helper_gps(a)
    b = helper_gps(b)
    if not a or not b:
        return False
    x = (a[0] - b[0]) ** 2
    y = (a[1] - b[1]) ** 2
    return (x + y) ** 1/2


# return the speed limit
def speed_limit(a, b):
    return city_connections[a+b][1]


# return estimated time needed to travel between two city
def estimate_time(a, b):
    return estimate_dist(a, b)/highest_speed_limit


# return actual time between two city
def time(a, b):
    return dist(a, b)/speed_limit(a, b)


# returns estimate Gallon between current and goal city
def estimate_gallon(a, b):
    # because mpg max-out at 30, gives least gallon
    speed = 30 
    return estimate_dist(a, b)/(400*speed/150*(1-speed/150)**4)


# returns actual mpg between two city
def mpg(a, b):
    speed = speed_limit(a, b)
    return 400*speed/150*(1-speed/150)**4


# return number of turns on this route
def turns(route):
    return len(route)-1


# return how many turns there could be
def estimate_turns(a, b):
    return estimate_dist(a, b)/longest_segment


# return the heuristic score of going to this city
# the score is going to be based on the cost_function
def heuristic(cur_city, end_city, cost_function):
    if cost_function == "segments":
        return estimate_turns(cur_city, end_city)
    if cost_function == "distance":
        return estimate_dist(cur_city, end_city)
    if cost_function == "time":
        return estimate_time(cur_city, end_city)
    if cost_function == "mpg":
        return estimate_gallon(cur_city, end_city)


# help return the g score based on cost function given
def g_score(a, b, cost_function):
    if cost_function == "segments":
        # return 1 because it's always 1 turn between neighbors
        return 1
    if cost_function == "distance":
        return dist(a, b)
    if cost_function == "time":
        return time(a, b)
    if cost_function == "mpg":
        return mpg(a, b)


# get neighbors
def neighbors(self):
    return city_map[self]


# returning all costs using data = {city: g, h, f, prev_city}
# [total-segments] [total-miles] [total-hours] [total-gas-gallons]
def prefix(route):
    miles = hours = gallons = 0
    for i in range(len(route)-1):
        a, b = route[i], route[i+1]
        temp_dist = dist(a, b)
        miles += temp_dist
        hours += time(a, b)
        gallons += temp_dist/mpg(a, b)
    return turns(route), miles, hours, gallons


# main search function, returns the best route based on the cost function given
def a_star(start_city, end_city, cost_function):
    data = {}
    fringe = [start_city]
    visited = []
    found = False
    temp = estimate_dist(start_city, end_city)
    data[start_city] = [0, temp, temp, ""]
    # n is not relevant to the algorithm
    # its for me checking how many expansion(s) it went through
    n = 0
    while not found:
        # sort according to it's f value, which is stored in data = {city: g, h, f, prev_city}
        sorted(fringe, key=lambda x: data[x][2])
        # pop the one with smallest f value
        current_city = fringe.pop(0)
        # make sure not to have visited city in fringe
        visited.append(current_city)
        # add neighbors into the fringe
        neighbor_cities = neighbors(current_city)
        for x in neighbor_cities:
            if x not in visited:
                fringe.append(x)
        for city in neighbor_cities:
            g = min(g_score(current_city, city, cost_function)+data[current_city][0], data[city][0]) \
                if city in data else g_score(current_city, city, cost_function) + data[current_city][0]
            h = heuristic(city, end_city, cost_function)
            temp = current_city if city not in data else data[city][3]
            '''data = {city: g, h, f, prev_city}'''
            data[city] = [g, h, g+h, temp]
        if end_city in fringe:
            found = True
        n += 1
    # restoring the best route from the end city
    res = [end_city]
    prev_city = end_city
    while prev_city != start_city:
        prev_city = data[prev_city][3]
        res.append(prev_city)
    res.reverse()
    # prefix_res is segments, miles, hours, gallons
    prefix_res = prefix(res)
    print(" ")
    print("This is the Best route found!:")
    print("====================================")
    print('total-segments:    ', prefix_res[0])
    print('total-miles:       ', prefix_res[1])
    print('total-hours:       ', prefix_res[2])
    print('total-gas-gallons: ', prefix_res[3])
    print(" ")
    print("Starting from here:")
    print("")
    for i in range(len(res)-1):
        print(res[i+1], city_connections[res[i]+res[i+1]][2])
    print("====================================")
    print(*prefix_res, *res)
    return prefix_res, res


if __name__ == '__main__':
    '''Used the following commands to test'''
    """
    route.py Bloomington,_Indiana Indianapolis,_Indiana segments
    route.py Bloomington,_Indiana Indianapolis,_Indiana distance
    route.py Bloomington,_Indiana Indianapolis,_Indiana time
    route.py Bloomington,_Indiana Indianapolis,_Indiana mpg
    """
    start_city, end_city, cost_function = sys.argv[1:]
    gps = read_gps("city-gps.txt")
    city_map, city_connections = read_citymap("road-segments.txt")
    longest_segment, highest_speed_limit = max([city_connections[x][:2] for x in city_connections])
    a_star(start_city, end_city, cost_function)

    """Uncomment this part to test using main"""
    # # Dont forget to comment out above parts
    # modes = ['segments', 'distance', 'time', 'mpg']
    # for x in modes:
    #     a_star('Bloomington,_Indiana', 'Indianapolis,_Indiana', x)
