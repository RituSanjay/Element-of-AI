# Assignment 1

**Please see the README files for each part of the assignment in their respective folders.**
