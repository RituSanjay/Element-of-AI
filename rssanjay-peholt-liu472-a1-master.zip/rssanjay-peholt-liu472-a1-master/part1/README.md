# Assignment 1, Part 1: The Luddy Puzzle
### Peter Holt

## The Problem
Part 1 of Assignment 1 gave us three variants of the 15-puzzle.
* The state space is any list of numbers 1-15 in any order plus one blank space (represented by a 0). The puzzle represents these numbers in a 4x4 matrix.  
* The successor function varies depending on the variant of the puzzle. In the "original" variant, any adjacent number (tile) can be swapped with the 0 (empty tiles). In the "circular" variant, any adjacent number can still be swapped with the 0, but this time each row or column wraps around the board. In the "luddy" variant, swaps must occur in an "L" shaped pattern.
* The goal state is a board that orders the numbers 1-15 in sequence with the 0 (empty space) at the end.

## The Heuristic function
The heuristic function for this problem was one we discussed in class. It looks at the number of tiles that are not in the correct spot, ignoring the empty space. Ideally I would have used a heuristic function that looked at Manhattan distance, as academic reading pointed to that being a more efficient algorithm, however I had trouble conceptualizing how to program that in Python.

## The Algorithm Overall
This part of the assignment started with a nearly complete template, so the task was to adapt it to run more efficiently and handle the "circular" and "luddy" variants, as it only handles the "original" variant to start. After developing the heuristic function (detailed above), I made sure that the fringe stored a new variable, which was the number of misplaced tiles from the heuristic function. The fringe was then sorted so the states that would be considered next were the ones with the fewest number of misplaced tiles. This increased the speed of the algorithm significantly.

Next I ensured that the algorithm kept track of previously used states to prevent an infinite loop occurring.

Finally I adapted the originally provided successor function to work for both the "circular" and the "luddy" variants. I kept these as separate functions and the code required some additional conditional statements to ensure it was pointed to the right function.
