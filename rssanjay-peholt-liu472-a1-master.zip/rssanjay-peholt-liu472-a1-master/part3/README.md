## Assignment 1 

### Part 3 : Choosing a Team

#### Problem Statement

Given a set of robots, each with skills and costs, form a group that has maximum total skills subject to a budget constraint.

#### Algorithm 

This problem makes use of the theory from the 0-1 knapsack algorithm (dynamic programming). The basic idea behind this is to keep storing the subproblems so taht we do not have to recompute again. This code is based on the explanation as given in the following sources:
* [0-1-knapsack](https://www.dyclassroom.com/dynamic-programming/0-1-knapsack-problem)
* M. T. Goodrich and R. Tamassia, "5.3 Dynamic Programming," in Algorithm Design: Foundations, Analysis and Internet Examples, Wiley, pp. 278-281.

#### Code Explanation

The code takes in two attributes - the first being a file containing the names of the robots, their skills and associated costs, while the second being the budget contraint. Once the file is read, the robots and their skills/costs are stored initially as a dictionary (as per original code provided). The nxt step is to create three new lists called robots, skill and rates. 

The new lists (robot, skill ,rate), the length of the file, and specified budget are given as the attributes of a the new function to solve the problem ( new_approx_solve()). The function makes use of a matrix 'K'  ( of size - budget+1 * length). So now, for each robot in the file, we check if its cost is greater than the cost in the previous cell, if yes then copy the contents (total skill) in the previous cell to current cell. On the other hand, if the nrobot under consideration has lesser cost, then we find the maximum of the total benefit of the previous cell and the total benefit obtained by adding the robot. Next, for every robot in the file, starting from the final row in the matrix (K), check if the total cost is less than the total cost of the cell just above it. This will give the list of robots which can be considered under given constraints. The idea to check the last row of the matrix was obtained from the following source:
* [dynamic-prg-java](https://www.guru99.com/knapsack-problem-dynamic-programming.html)




