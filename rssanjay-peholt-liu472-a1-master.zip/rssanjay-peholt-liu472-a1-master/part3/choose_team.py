#!/usr/local/bin/python3
#
# choose_team.py : Choose a team of maximum skill under a fixed budget
#
# Code by: Ritu Sanjay
#
# Based on skeleton code by D. Crandall, September 2019
#
#************************NOTE****************************************************
#
# * This code is based on the 0-1 knapsack problem as described in the tutorial:
#   https://www.dyclassroom.com/dynamic-programming/0-1-knapsack-problem
# * also refers to algorithms as specified in the following book:
#   M. T. Goodrich and R. Tamassia, "5.3 Dynamic Programming," in Algorithm Design: Foundations, Analysis and Internet Examples, Wiley, pp. 278-281.
#
#********************************************************************************
import sys
import numpy as np

def load_people(filename):
    people={}
    with open(filename, "r") as file:
        for line in file:
            l = line.split()
            people[l[0]] = [ float(i) for i in l[1:] ] 
    return people


# This function implements a greedy solution to the problem:
#  It adds people in decreasing order of "skill per dollar,"
#  until the budget is exhausted. It exactly exhausts the budget
#  by adding a fraction of the last person.
#
def approx_solve(people, budget):

    solution=()
    for (person, (skill, cost)) in sorted(people.items(), key=lambda x: x[1][0]/x[1][1]):
        if budget - cost > 0:
            solution += ( ( person, 1), )
            budget -= cost
        else:
            return solution + ( ( person, budget/cost ), )

    return solution

#this new solution approximation function is based on the
# 0-1 knapsack problem and dynamic programming
def new_approx_solve(budget,robot,rate,skill,n):
    K = np.zeros((n+1,int(budget+1)),dtype=np.float64)
    sol = np.zeros((n+1,int(budget+1)),dtype=np.float64)
    #the matrix will be skill*rate

    
    for i in range(1,n+1):
        c=rate[i-1]
        b=skill[i-1]
        #print("%f %f" %(c,b))
        for j in range(1,int(budget+1)):
            if c>j:
                K[i][j] = K[i-1][int(j)]
            else:
                K[i][j] = max(K[i-1][int(j)],K[i-1][int(j-c)] + b)
                sol[i][j]=1
            
    TotCost=budget
    chosen_robots=[]
    #print(K)
    #check which of the robot combinations will return the optimal solution
    #note that this starts from the end of the K-matrix , where maximum skill has been found - check last row for final solution
    
    for x in range(len(robot),0,-1):
        
        # idea to compare the benefits of the final value in each row of K was found from the following java code (line 27):
        # https://www.guru99.com/knapsack-problem-dynamic-programming.html
        flag=K[x][int(TotCost)] != K[x-1][int(TotCost)]
        if flag:
            r = rate[x-1]
            chosen_robots.append(robot[x-1])
            TotCost=TotCost-r

    #stores the index for the chosen robots
    final_sol=[]
    for y in range(0,n):
        if robot[y] in chosen_robots:
            final_sol.append(1)
        else:
            final_sol.append(0)
            
        
            
    return final_sol

        
        


if __name__ == "__main__":

    if(len(sys.argv) != 3):
        raise Exception('Error: expected 2 command line arguments')

    budget = float(sys.argv[2])
    people = load_people(sys.argv[1])
    
    #length of dictonary
    n=len(people)
    #divide the dictionary into lists
    robot=[]
    skill=[]
    rate=[]
    for person in people:
        robot.append(person)
        skill.append(people[person][0])
        rate.append(people[person][1])
    #print(n)
    #print(robot)
    #print(skill)
    #print(rate)
    solution=new_approx_solve(budget,robot,rate,skill,n)
    #print(solution)
    #solution = approx_solve(people, budget)
    #count number of robots chosen:
    count=0
    cost=0
    sk=0
    for i in range(0,len(solution)):
        if solution[i]==1:
            count=count+1
            cost=cost+rate[i]
            sk=sk+skill[i]

    print("Found a group with %d people costing %f with total skill %f" %( count, cost, sk))
    for i in range(0,len(solution)):
        if solution[i]==1:
            print("%s %f " %(robot[i],1))

    #for s in solution:
        #print("%s %f" % s)

