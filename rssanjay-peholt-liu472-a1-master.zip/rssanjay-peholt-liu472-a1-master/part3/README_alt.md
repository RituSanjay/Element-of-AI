# Assignment 1, Part 3: Choosing a Team (ALT)
### Peter Holt

**ALTERNATIVE SOLUTION: This is an alternative solution to Part 3 and references the "choose_team_alt.py" file. Please see the "README.md" and "choose_team.py" files for our group's primary solution.**

## The Problem
Part 3 of Assignment 1 gave us a problem of selecting a team of robots that would maximize their skill and keep their cost under a given budget. Each robot has a set skill and cost.
* The state space is a group of robots under the given cost.
* The successor function would be any other group of robots under the given cost.
* The goal state is a group of robots that has the maximum skill for the given budget, no fractions of robots allowed.

## Heuristic or Not?
I found this problem challenging because I could not find a function that would both maximize skill, minimize cost, and not split robots into some fraction. After a discussion during class office hours, I decided to approach this problem as a local search by adding some randomness. I'm not sure if it qualifies as a true local search or not.

## The Algorithm Overall
The algorithm starts as it did in the provided template. It has a list of robots and sorts them by some ratio of skill and cost, and then starts adding them to the group. Once the group is full it stops and does not divide the final robot. It assumes at this point that the given group is the best solution.

Next it starts the same process again, but adds some randomness. The algorithm will still sort the robots in the same way, but there is a random chance it will skip some and go on to the next robot. It does this a set number of times, each time comparing the partially randomly generated group to the original group. If one ends up with more skill then it makes that the best solution. The algorithm cuts off after an arbitrary number of iterations and returns the best group it found.
