#!/usr/local/bin/python3
#
# choose_team.py : Choose a team of maximum skill under a fixed budget
#
# Code by: Peter Holt (peholt)
#
# Based on skeleton code by D. Crandall, September 2019
#
import sys
import time
import random

def load_people(filename):
    people={}
    with open(filename, "r") as file:
        for line in file:
            l = line.split()
            people[l[0]] = [ float(i) for i in l[1:] ] 
    return people


#  This function implements a greedy solution to the problem:
#  It adds people in decreasing order of "cost per skill,"
#  until the budget is exhausted. It does NOT allow for fractions
#  of a robot
def approx_solve(people, budget):

    initial_solution = ()
    initial_budget = budget
    for (person, (skill, cost)) in sorted(people.items(), key=lambda x: x[1][1]/x[1][0]):
        if initial_budget - cost > 0:
            initial_solution += ( ( person, 1), )
            initial_budget -= cost

    best_solution = initial_solution
    best_solution_skill = sum(people[p][0]*f for p,f in initial_solution)
    print("Initial Solution Skill:", best_solution_skill)


    for k in range(0,40):
        new_solution = ()
        new_budget = budget
        for (person, (skill, cost)) in sorted(people.items(), key=lambda x: x[1][1] / x[1][0]):
            # Idea to generate a random choice from https://pynative.com/python-random-choice/
            if random.choice([1,2,3,4,5]) == 5:
                None
            elif new_budget - cost > 0:
                new_solution += ((person, 1),)
                new_budget -= cost

        new_solution_skill = sum(people[p][0]*f for p,f in new_solution)
        print("New Solution Skill:", new_solution_skill)

        if new_solution_skill > best_solution_skill:
            best_solution = new_solution

    return best_solution



if __name__ == "__main__":

    if(len(sys.argv) != 3):
        raise Exception('Error: expected 2 command line arguments')

    budget = float(sys.argv[2])
    people = load_people(sys.argv[1])
    solution = approx_solve(people, budget)

    print("Found a group with %d people costing %f with total skill %f" % \
               ( len(solution), sum(people[p][1]*f for p,f in solution), sum(people[p][0]*f for p,f in solution)))

    for s in solution:
        print("%s %f" % s)

